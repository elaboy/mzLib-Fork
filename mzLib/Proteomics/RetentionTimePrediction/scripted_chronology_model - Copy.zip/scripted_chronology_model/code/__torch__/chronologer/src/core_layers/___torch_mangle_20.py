class resnet_block(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  in_channels : int
  out_channels : int
  process_blocks : __torch__.torch.nn.modules.container.___torch_mangle_19.Sequential
  activate : __torch__.torch.nn.modules.activation.ReLU
  shortcut : __torch__.torch.nn.modules.container.___torch_mangle_14.Sequential
  term_block : __torch__.torch.nn.modules.linear.Identity
  def forward(self: __torch__.chronologer.src.core_layers.___torch_mangle_20.resnet_block,
    x: Tensor) -> Tensor:
    in_channels = self.in_channels
    out_channels = self.out_channels
    if torch.ne(in_channels, out_channels):
      shortcut = self.shortcut
      residual = (shortcut).forward(x, )
    else:
      residual = x
    process_blocks = self.process_blocks
    x0 = (process_blocks).forward(x, )
    term_block = self.term_block
    x1 = (term_block).forward(x0, )
    x2 = torch.add(x1, residual)
    activate = self.activate
    return (activate).forward(x2, )
