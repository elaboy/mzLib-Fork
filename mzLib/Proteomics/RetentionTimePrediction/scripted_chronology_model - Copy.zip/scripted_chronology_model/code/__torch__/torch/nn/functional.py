def embedding(input: Tensor,
    weight: Tensor,
    padding_idx: Optional[int]=None,
    max_norm: Optional[float]=None,
    norm_type: float=2.,
    scale_grad_by_freq: bool=False,
    sparse: bool=False) -> Tensor:
  _0 = "AssertionError: Padding_idx must be within num_embeddings"
  if torch.__isnot__(padding_idx, None):
    padding_idx1 = unchecked_cast(int, padding_idx)
    if torch.gt(padding_idx1, 0):
      _1 = torch.lt(padding_idx1, torch.size(weight, 0))
      if _1:
        pass
      else:
        ops.prim.RaiseException(_0)
      padding_idx2 = padding_idx1
    else:
      if torch.lt(padding_idx1, 0):
        _2 = torch.neg(torch.size(weight, 0))
        if torch.ge(padding_idx1, _2):
          pass
        else:
          ops.prim.RaiseException(_0)
        padding_idx4 = torch.add(torch.size(weight, 0), padding_idx1)
        padding_idx3 = padding_idx4
      else:
        padding_idx3 = padding_idx1
      padding_idx2 = padding_idx3
    padding_idx0 = padding_idx2
  else:
    padding_idx0 = -1
  if torch.__isnot__(max_norm, None):
    input0 = torch.contiguous(input)
  else:
    input0 = input
  _3 = torch.embedding(weight, input0, padding_idx0, scale_grad_by_freq, sparse)
  return _3
def batch_norm(input: Tensor,
    running_mean: Optional[Tensor],
    running_var: Optional[Tensor],
    weight: Optional[Tensor]=None,
    bias: Optional[Tensor]=None,
    training: bool=False,
    momentum: float=0.10000000000000001,
    eps: float=1.0000000000000001e-05) -> Tensor:
  _4 = __torch__.torch.nn.functional._verify_batch_size
  if training:
    _5 = _4(torch.size(input), )
  else:
    pass
  _6 = torch.batch_norm(input, weight, bias, running_mean, running_var, training, momentum, eps, True)
  return _6
def relu(input: Tensor,
    inplace: bool=False) -> Tensor:
  if inplace:
    result = torch.relu_(input)
  else:
    result = torch.relu(input)
  return result
def dropout(input: Tensor,
    p: float=0.5,
    training: bool=True,
    inplace: bool=False) -> Tensor:
  _7 = "dropout probability has to be between 0 and 1, but got {}"
  if torch.lt(p, 0.):
    _8 = True
  else:
    _8 = torch.gt(p, 1.)
  if _8:
    ops.prim.RaiseException(torch.format(_7, p), "builtins.ValueError")
  else:
    pass
  if inplace:
    _9 = torch.dropout_(input, p, training)
  else:
    _9 = torch.dropout(input, p, training)
  return _9
def _verify_batch_size(size: List[int]) -> NoneType:
  _10 = "Expected more than 1 value per channel when training, got input size {}"
  size_prods = size[0]
  size_prods0 = size_prods
  for i in range(torch.sub(torch.len(size), 2)):
    size_prods1 = torch.mul(size_prods0, size[torch.add(i, 2)])
    size_prods0 = size_prods1
  if torch.eq(size_prods0, 1):
    ops.prim.RaiseException(torch.format(_10, size), "builtins.ValueError")
  else:
    pass
  return None
