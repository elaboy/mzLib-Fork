class chronologer_model(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  seq_embed : __torch__.torch.nn.modules.sparse.Embedding
  resnet_blocks : __torch__.torch.nn.modules.container.___torch_mangle_21.Sequential
  dropout : __torch__.torch.nn.modules.dropout.Dropout
  flatten : __torch__.torch.nn.modules.flatten.Flatten
  output : __torch__.torch.nn.modules.linear.Linear
  def forward(self: __torch__.chronologer_model,
    x: Tensor) -> Tensor:
    seq_embed = self.seq_embed
    x0 = torch.transpose((seq_embed).forward(x, ), 1, -1)
    resnet_blocks = self.resnet_blocks
    x1 = (resnet_blocks).forward(x0, )
    dropout = self.dropout
    x2 = (dropout).forward(x1, )
    flatten = self.flatten
    x3 = (flatten).forward(x2, )
    output = self.output
    return (output).forward(x3, )
